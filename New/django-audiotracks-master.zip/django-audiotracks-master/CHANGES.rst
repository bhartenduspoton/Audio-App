Changes
~~~~~~~

v0.2.4 (unreleased)
___________________ 

- add "js-" prefix to classes used by JavaScript code


v0.2.4 (2014-10-14)
___________________ 

- Add Django 1.7 support
- Drop Django 1.5 support


v0.2.3 (2014-02-02)
___________________ 

- Add tox and travis config files
- Add Python 3 support


v0.2.2 (2013-04-08)
___________________ 

- make sure slug doesn't get too long
- skip tracks MediaElement.js cannot read
- exclude example_project from distribution


v0.2.1 (2012-05-25)
___________________

- fix doc

v0.2 (2012-05-25)
_________________

- integrate MediaElement.js audio player to default templates
- display file type and size in download button
- serve m3u playlist

v0.1.1 (2012-05-19)
___________________


- add other user's tracks listing
- update repository URL
        
v0.1 (2012-02-21)
_________________

Initial release.
